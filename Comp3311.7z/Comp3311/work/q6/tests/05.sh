./q6 Australia 1900
