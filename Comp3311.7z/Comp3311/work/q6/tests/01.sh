./q6 'Australia' 2006
