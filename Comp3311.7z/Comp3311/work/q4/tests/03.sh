psql footy -c "select * from q4('China','Korea');"
