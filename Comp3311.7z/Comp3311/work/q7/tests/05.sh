./q7 'John Smith'
