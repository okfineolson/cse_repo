-- COMP3311 20T3 Final Exam
-- Q1: view of teams and #matches

-- ... helper views (if any) go here ...

create or replace view Q1(team,nmatches)
as
select Teams.country ,count(*)  
from Teams ,Involves 
where Involves.team = Teams.id
GROUP BY  Teams.country
;

