-- COMP3311 20T3 Final Exam
-- Q2: view of amazing goal scorers

-- ... helpers go here ...

create or replace view Q2(player,ngoals)
as
select Players.name,count(Goals.id)
from Players join Goals on (Goals.scoredBy = Players.id)
where Goals.rating = 'amazing'
GROUP BY Players.name
having count(Goals.id) > 1;