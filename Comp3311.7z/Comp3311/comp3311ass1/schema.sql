-- COMP3311 20T3 Assignment 1
-- Calendar schema
-- Written by Jin-ao Olson Zhang

-- Types

create type AccessibilityType as enum ('read-write','read-only','none');
create type InviteStatus as enum ('invited','accepted','declined');
create type visibilityType as enum ('public','private');
-- add more types/domains if you want

-- Tables
create table Users (
	id      	serial primary key,
	email       text not null unique,
	name        text not null,
	passwd		text not null,
	is_admin	boolean not null
);
create table Groups (
	id     		serial primary key,
	name        text not null,
	Owner 		integer not null,
	foreign key (Owner) references Users(id)

);
create table Member (
	userid 		integer references Users(id),
	groupid 	integer references Groups(id),
	primary key (userid,groupid)
);
create table Calendar (
	id 			serial primary key,
	colour		text not null,
	name		text not null,
	default_access 	AccessibilityType not null,
	owner 		integer not null,
	foreign key (owner) references Users(id)
);
create table accessibility (
	userid 		integer references Users(id),
	calendarid 	integer references Calendar(id),
	access 		AccessibilityType not null,
	primary 	key (calendarid,userid)
);
create table  subscribed (
	userid 		integer references Users(id),
	calendarid 	integer references Calendar(id),
	colour		text ,
	primary key (calendarid,userid)
);

create table Event (
	id 			serial primary key,
	title 		text not null,
	start_time 	time,
	end_time 	time,
	location 	text,
	visibility 	visibilityType not null,--here
	owner 		integer not null,
	foreign key (owner) references Users(id),
	part_of 	integer not null,
	foreign key (part_of) references Calendar(id)
);
create table one_day_Event (
	id 			integer primary key,
	date 		date not null,
	foreign key (id) references Event(id)

);
create table spanning_event (
	id 			integer primary key,
	start_date 	date not null,
	end_date 	date not null,
	foreign key (id) references Event(id)

);
create table recurring_event (
	id 			integer primary key,
	ntimes 		integer ,
	start_date 	date not null,
	end_date 	date ,
	foreign key (id) references Event(id)

);
create table alarms(
	event_id 	integer references Event(id),
	alarm 		integer not null,
	primary key (event_id,alarm)

);
create table weekly_event(
	id 			integer primary key,
	dayofweek 	char not null,
	frequency 	integer not null,
	foreign key (id) references Event(id)
);
create table monthlybydayEvent(
	id 			integer primary key,
	dayofweek 	char not null,
	weekinmonth	integer not null,
	foreign key (id) references Event(id)
);
create table monthlybydateEvent(
	id 			integer primary key,
	dateinmonth	integer not null,
	foreign key (id) references Event(id)
);
create table AnnualEvent(
	id 			integer primary key,
	date		date not null,
	foreign key (id) references Event(id)
);
create table invited(
	Eventid 	integer references Event(id),
	Userid 		integer references Users(id),
	status  	InviteStatus not null,
	primary key(Eventid,Userid)
);
-- etc. etc. etc.
