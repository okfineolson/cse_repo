# COMP3311 20T3 Ass3 ... Python helper functions
# add here any functions to share between Python scripts
import psycopg2



class Connector:
    def __init__(self):
        try:
            self.db = psycopg2.connect("dbname = imdb")
            self.cursor = self.db.cursor()
        except psycopg2.Error as err:
            raise err
    def execute(self, sql, params=None):
        try:
            self.cursor.execute(sql, params)
        except psycopg2.Error as err:
            raise err
        return self.cursor.fetchall()
    def close(self):
        self.db.close()







