public interface Semaphore3151 {

    /**
     * Also known as wait
     ***/
    void P();

    /**
     * Also known as signal
     ***/
    void V();
}
