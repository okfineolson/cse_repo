public class WeakSemaphore implements Semaphore3151 {
    //TODO: Add private state here as needed
    public WeakSemaphore(int v) {
        //TODO: implement
    }
    @Override
    public void P() {
        //TODO: Used synchronized methods and the Java wait() method to add the process to the waiting set.
    }

    @Override
    public void V() {
        //TODO: Use the Java notify() method to awaken a waiting process.
    }

}
