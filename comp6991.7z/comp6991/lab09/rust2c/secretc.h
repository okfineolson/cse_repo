int secret_c_calculation(int x, double y, char z);
