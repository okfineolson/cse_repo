use std::fs;
use std::env;
use std::io::{self, BufRead};
use std::error::Error;
use std::collections::HashMap;

// NOTE: You *may not* change the names or types of the members of this struct.
//       You may only add lifetime-relevant syntax.

// Add a lifetime specifier to the SearchResult struct
pub struct SearchResult<'a> {
    pub matches: Vec<&'a str>,
    pub contains: &'a str
}

// Implement the find_sentences_containing function
fn find_sentences_containing<'a>(text: &'a str, contains: &'a str) -> SearchResult<'a> {
    let sentences: Vec<&'a str> = text.split('.').map(|s| s.trim()).collect();
    let matches: Vec<&'a str> = sentences.iter().filter(|&sentence| sentence.contains(contains)).cloned().collect();
    SearchResult { matches, contains }
}

// Implement the count_sentence_matches function
fn count_sentence_matches(searches: Vec<SearchResult>) -> HashMap<&str, i32> {
    let mut counts = HashMap::new();
    for search in searches {
        for sentence in search.matches {
            let count = counts.entry(sentence).or_insert(0);
            *count += 1;
        }
    }
    counts
}


/////////// DO NOT CHANGE BELOW HERE ///////////

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    let file_path = &args[1];

    let text = fs::read_to_string(file_path)?;
    let stdin = io::stdin();
    let matches = stdin.lock().lines().map(|l| l.unwrap()).collect::<Vec<_>>();
    let mut sentence_matches = {
        let mut found = vec![];


        for line in matches.iter() {
            let search_result = find_sentences_containing(&text, line);
            println!("Found {} results for '{}'.", search_result.matches.len(), search_result.contains);
            found.push(search_result);
        }

        count_sentence_matches(found).into_iter().collect::<Vec<_>>()
    };
    sentence_matches.sort();

    for (key, value) in sentence_matches {
        println!("'{}' occured {} times.", key, value);
    }

    Ok(())
}
