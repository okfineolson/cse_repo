
use std::result;
use std::io::{self, ErrorKind};
use std::sync::{Arc, Mutex};
pub use unsvg::Color;
use std::collections::HashMap;
use once_cell::sync::Lazy;
pub static VARIABLES: Lazy<Arc<Mutex<HashMap<String, f32>>>> = Lazy::new(|| Arc::new(Mutex::new(HashMap::new())));

#[derive(Clone)]
pub struct Block {
    pub commands: Vec<Command>,
}
#[derive(Clone)]
pub enum Parameter {
    F32(f32),
    Variable(String),
  
}

#[derive(Clone)]
pub enum Command {
    Block(Block),
    NoOp,
    PenUp,
    PenDown,
    Forward(Parameter),
    Back(Parameter),
    Left(Parameter),
    Right(Parameter),
    SetPenColor(Parameter),
    Turn(Parameter),
    SetHeading(Parameter),
    SetX(Parameter),
    SetY(Parameter),
    Make(String, Parameter),
    AddAssign(String, Parameter),
    IfEq(Parameter, Parameter, Block),
    WhileEq(Parameter, Parameter, Block),
    /*
    DefineProcedure(String, Vec<String>, Block),
    CallProcedure(String,Vec<String>)*/
    // other commands...
}
fn evaluate_expression(tokens: &[&str] ) -> Result<f32> {
    let mut stack: Vec<f32> = Vec::new();

    for token in tokens.iter().rev() { 
        match *token {
            "+" => {
                let rhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                let lhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                stack.push(lhs + rhs);
            },
            "-" => {
                let rhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                let lhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                stack.push(rhs - lhs);
            },
            "*" => {
                let rhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                let lhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                stack.push(rhs * lhs);
            },
            "/" => {
                let rhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                let lhs = stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing argument for +"))?;
                stack.push(rhs / lhs);
            },
            "GT" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();

                stack.push(if rhs > lhs { 999.99 } else { 1000.00 });
            },
            "EQ" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();

                stack.push(if rhs == lhs { 999.99 } else { 1000.00 });
            },
            "NE" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();

                stack.push(if rhs != lhs { 999.99 } else { 1000.00 });
            },
            "LT" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();
              

                stack.push(if rhs < lhs { 999.99 } else { 1000.00 });
            },
            "AND" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();
  
                stack.push(if lhs == 999.99 && rhs == 999.99 { 999.99 } else { 1000.00 });
            },
            "OR" => {
                if stack.len() < 2 {
                    return Err(io::Error::new(ErrorKind::InvalidInput, "Not enough operands for GT"));
                }
                let rhs = stack.pop().unwrap();
                let lhs = stack.pop().unwrap();
                stack.push(if lhs == 999.99 || rhs == 999.99 { 999.99 } else { 1000.00 });
            },
            _ => {
                let token = token.trim_matches('"');
                let token = token.trim_matches(':');

                if let Ok(num) = token.parse::<f32>() {
                    stack.push(num);
                } else {

                    if let Some(num) = VARIABLES.lock().unwrap().get(token){
                     
                        stack.push(*num);

                    }else{
                        return Err(io::Error::new(ErrorKind::InvalidInput, "Unknown token"));
                    }
                }
            },
        }
    }
    stack.pop().ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Invalid expression"))
}


fn check_args(tokens: &[&str], expected: usize) -> Result<()> {
    if tokens.len() != expected {

        let extra_args = tokens[expected..].join(", ");
        Err(io::Error::new(ErrorKind::InvalidInput, format!("Extra arguments: [\"\\{}\"]", extra_args)))
    } else {
        Ok(())
    }
}
fn parse_block(tokens: &[String]) -> Result<(Block)> {
    let mut commands = Vec::new();
    let mut index = 0;
    let mut bracket_count = 0;
    let token1 = tokens[0].split("!");
    //eprintln!("{:?}",tokens);
    for i in token1{
        let i  = i.trim_start_matches("[")
        if i.starts_with("IF") || i.starts_with("WHILE"){
            let command = parse_command(&i)?;
            commands.push(command);

        }else{
            for j in i.split("\n"){
                let command = parse_command(&j)?;
                commands.push(command);

            }
        }
    }

 

    Ok(Block { commands })
}

fn split_input<'a>(input: &'a str) -> Vec<&'a str> {
    let mut parts = Vec::new();

    // 找到第一个 '[' 的位置
    if let Some(bracket_start_index) = input.find('[') {
        // 找到对应的 ']' 的位置
        let mut bracket_end_index = None;
        let mut bracket_counter = 1;
        for (i, char) in input[bracket_start_index + 1..].chars().enumerate() {
            match char {
                '[' => bracket_counter += 1,
                ']' => {
                    bracket_counter -= 1;
                    if bracket_counter == 0 {
                        bracket_end_index = Some(bracket_start_index + 1 + i);
                        break;
                    }
                },
                _ => {}
            }
        }

        if let Some(end_index) = bracket_end_index {

            let before_bracket = &input[..bracket_start_index].trim_end();
            parts.extend(before_bracket.split_whitespace());


            let bracket_content = &input[bracket_start_index..=end_index];
            parts.push(bracket_content);

            if end_index + 1 < input.len() {
                let after_bracket = &input[end_index + 1..].trim_start();
                if !after_bracket.is_empty() {
                    parts.push(after_bracket);
                }
            }
        } else {

            parts.extend(input.split_whitespace());
        }
    } else {
        parts.extend(input.split_whitespace());
    }

    parts
}

trait StringExtensions {
    fn contains_any_arithmetic_operation(&self) -> bool;
}
impl StringExtensions for &str {
    fn contains_any_arithmetic_operation(&self) -> bool {
        self.contains('+') || self.contains('-') || self.contains('*') || self.contains('/')||
        self.contains("LT") || self.contains("EQ") ||self.contains("NE")||self.contains("GT")||
        self.contains("AND") ||self.contains("OR")
    }
}
fn parse_command_with_single_parameter(expected: usize,tokens: &[&str], command_constructor: fn(Parameter) -> Command) -> Result<Command> {
    check_args(tokens, expected)?;
    tokens.get(1)
        .ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing parameter for command"))
        .and_then(|&arg| {
            let arg = arg.trim_matches('"');
            if arg.starts_with(":") {
                Ok(command_constructor(Parameter::Variable(arg[1..].to_string())))
            } else {
                arg.parse::<f32>()
                    .map_err(|_| io::Error::new(ErrorKind::InvalidInput, "Invalid parameter for command"))
                    .map(|value| command_constructor(Parameter::F32(value)))
            }
        })
}
pub fn parse_command(line: &str) -> Result<Command> {
    
    let mut tokens: Vec<&str> = line.trim().split(" ").collect();

    if line.starts_with("IF") || line.starts_with("WHILE") {
        tokens = split_input(&line);
    }

    if tokens.is_empty() {
        return Ok(Command::NoOp);
    }
    let trimmed_line = line.trim();
    
    // Ignore comment or empty lines by returning a NoOp command
    if trimmed_line.starts_with("//") || trimmed_line.is_empty() {
        return Ok(Command::NoOp);
    }
    eprintln!("{:?}",line);
    match tokens[0] {
        "IF" => {
       
            let string_tokens: Vec<String> = tokens.iter().map(|&s| s.to_string()).collect();
            
            // 找到第一个包含"["的元素的索引
            let bracket_start_index = string_tokens.iter().position(|r| r.contains('[')).unwrap_or(string_tokens.len());
            // 从这个索引开始，传递剩余的元素给`parse_block`
            //let modified = tokens.split("!")
            
            let block = parse_block(&string_tokens[bracket_start_index..])?;
            match tokens[1]{
                "EQ" =>{

                    if tokens.len() != 5{
                        let condition_result = evaluate_expression(&tokens[1..bracket_start_index])?;
                        Ok(Command::IfEq(Parameter::F32(condition_result),Parameter::F32( 999.99), block))
                    }else{
                        let arg1 = tokens[2];
                        let arg2 = tokens[3];
                        //eprintln!("{} {}",arg1,arg2);
                        let newarg1 = arg1.trim_matches('"');
                        let newarg1 = newarg1.trim_matches(':');
                        let newarg2 = arg2.trim_matches('"');
                        let newarg2 = newarg2.trim_matches(':');
                        let param1 = if arg1.starts_with("\"") && arg2 != "\"TRUE" && arg2 != "\"FALSE" {
        
                            Parameter::F32(newarg1.parse::<f32>().map_err(|_| io::Error::new(ErrorKind::InvalidInput, "Invalid number for Whileeq command1"))?)
                        } else {
                            
                            Parameter::Variable(newarg1.to_string())
                        };
                        let param2 = if arg2.starts_with("\"") && arg2 != "\"TRUE" && arg2 != "\"FALSE"{
        
                            Parameter::F32(newarg2.parse::<f32>().map_err(|_| io::Error::new(ErrorKind::InvalidInput, "Invalid number for Whileeq command2"))?)
                        } else {
                            
                            Parameter::Variable(newarg2.to_string())
                        };
                        
                        Ok(Command::IfEq(param1, param2, block))
                    }
                },
                _ =>{
                    if tokens.len() <=3{
                        let name = tokens[1];
                        let name = name.trim_matches('"');
                        let name = name.trim_matches(':');
                        Ok(Command::IfEq(Parameter::Variable(name.to_string()),Parameter::F32( 999.99), block))
                    }else{
                        let condition_result = evaluate_expression(&tokens[1..bracket_start_index])?;
                        Ok(Command::IfEq(Parameter::F32(condition_result),Parameter::F32( 999.99), block))
                    }
                }
            }

        },
        "WHILE" => {
            let string_tokens: Vec<String> = tokens.iter().map(|&s| s.to_string()).collect();
            // 找到第一个包含"["的元素的索引
            let bracket_start_index = string_tokens.iter().position(|r| r.contains('[')).unwrap_or(string_tokens.len());
            // 从这个索引开始，传递剩余的元素给`parse_block`
            let block = parse_block(&string_tokens[bracket_start_index..])?;
            match tokens[1]{
                "EQ" =>{
                    let arg1 = tokens[2];
                    let arg2 = tokens[3];
                    //eprintln!("{} {}",arg1,arg2);
                    let newarg1 = arg1.trim_matches('"');
                    let newarg1 = newarg1.trim_matches(':');
                    let newarg2 = arg2.trim_matches('"');
                    let newarg2 = newarg2.trim_matches(':');
                    let param1 = if arg1.starts_with("\"") && arg2 != "\"TRUE" && arg2 != "\"FALSE" {
    
                        Parameter::F32(newarg1.parse::<f32>().map_err(|_| io::Error::new(ErrorKind::InvalidInput, "Invalid number for Whileeq command1"))?)
                    } else {
                        
                        Parameter::Variable(newarg1.to_string())
                    };
                    let param2 = if arg2.starts_with("\"") && arg2 != "\"TRUE" && arg2 != "\"FALSE"{
    
                        Parameter::F32(newarg2.parse::<f32>().map_err(|_| io::Error::new(ErrorKind::InvalidInput, "Invalid number for Whileeq command2"))?)
                    } else {
                        
                        Parameter::Variable(newarg2.to_string())
                    };
                    
                    return Ok(Command::WhileEq(param1, param2, block))
                },
                _ =>{
                    if tokens.len() <=3{
                        let name = tokens[1];
                        let name = name.trim_matches('"');
                        let name = name.trim_matches(':');
                        Ok(Command::WhileEq(Parameter::Variable(name.to_string()),Parameter::F32( 999.99), block))
                    }else{
                        let condition_result = evaluate_expression(&tokens[1..bracket_start_index])?;
                        Ok(Command::WhileEq(Parameter::F32(condition_result),Parameter::F32( 999.99), block))
                    }
                }
            }

        },
        "PENUP" => {
            check_args(&tokens, 1)?;
            Ok(Command::PenUp)
        },
        "PENDOWN" => {
            check_args(&tokens, 1)?;

            Ok(Command::PenDown)
        },
        "FORWARD" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::Forward(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::Forward)
            }
        },
        "BACK" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::Back(Parameter::F32(expr_result)))
            } else {
                parse_command_with_single_parameter(2,&tokens, Command::Back)
            }
        },
        "LEFT" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::Left(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::Left)
            }
        },
        "RIGHT" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::Right(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::Right)
            }
        },
        "SETPENCOLOR" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::SetPenColor(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::SetPenColor)
            }
        },
        "TURN" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::Turn(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::Turn)
            }
        },
        "SETHEADING" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::SetHeading(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::SetHeading)
            }
        },
        "SETX" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::SetX(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::SetX)
            }
        },
        "SETY" => {
            if tokens[1].contains_any_arithmetic_operation() { 
                let expr_result = evaluate_expression(&tokens[1..])?;
                Ok(Command::SetY(Parameter::F32(expr_result)))
            } else {

                parse_command_with_single_parameter(2,&tokens, Command::SetY)
            }
        },
        "MAKE" => {
            let name = tokens.get(1)
                    .ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing name for make command"))?;
            let param = tokens.get(2)
                .ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing parameter for make command"))?;
            // Remove the quotes around the name and parameter
            let name = name.trim_matches('"');
            let name = name.trim_matches(':');
            let param = param.trim_matches('"');
            let param = param.trim_matches(':');

            if param.contains_any_arithmetic_operation() {
                
                let condition_result = evaluate_expression(&tokens[2..])?;
                let param = Parameter::F32(condition_result);
                
                Ok(Command::Make(name.to_string(), param))
            }else {
                check_args(&tokens, 3)?;
                

                let param = if let Ok(distance) = param.parse::<f32>() {
                    Parameter::F32(distance)
                } else {
                    
                    Parameter::Variable(param.to_string())
                };
                Ok(Command::Make(name.to_string(), param))
            }
        },
        "ADDASSIGN" => {
            check_args(&tokens, 3)?;
            let name = tokens.get(1)
                .ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing name for AddAssign command"))?;
            let param = tokens.get(2)
                .ok_or_else(|| io::Error::new(ErrorKind::InvalidInput, "Missing parameter for AddAssign command"))?;
            // Remove the quotes around the name and parameter
            let name = name.trim_matches('"');
            let param = param.trim_matches('"');
            let param = param.trim_matches(':');
            let param = if let Ok(distance) = param.parse::<f32>() {
                Parameter::F32(distance)
            } else {
                Parameter::Variable(param.to_string())
            };
            Ok(Command::AddAssign(name.to_string(), param))
        },
        
        
        
        // Add cases for other commands as needed
        _ => Err(io::Error::new(ErrorKind::InvalidInput, format!("Unknown command{}",tokens[0] ))),
    }
}


type Result<T> = result::Result<T, io::Error>;
