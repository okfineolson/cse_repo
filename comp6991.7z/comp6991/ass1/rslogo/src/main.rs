use clap::Parser;

use std::fs::File;
use std::io::{self, BufRead};
use std::path::Path;

use command::parse_command;
use turtle::Turtle;

#[derive(Parser)]
struct Args {
    /// Path to a logo program file
    file_path: std::path::PathBuf,

    /// Path to the output SVG or PNG file
    image_path: std::path::PathBuf,

    /// Height of the image
    height: u32,

    /// Width of the image
    width: u32,
}

use std::env;
use std::process;

// Assume Turtle, Image, and other relevant structs and functions are defined elsewhere

fn main() -> Result<(), std::io::Error> {
    let args: Vec<String> = env::args().collect();

    // Checking if we have enough arguments passed to the program
    if args.len() < 5 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "Usage: rslogo <input_file> <output_file> <height> <width>",
        ));
    }

    let file_path = Path::new(&args[1]);
    let image_path = Path::new(&args[2]);
    let height: u32 = args[3].parse().expect("Height must be a number");
    let width: u32 = args[4].parse().expect("Width must be a number");

    // Here, you'd initialize Turtle with the specified image width and height
    // Assuming Turtle::new() can take height and width as parameters
    let mut turtle = Turtle::new(width, height);
    let file = File::open(file_path)?;
    let reader = io::BufReader::new(file);

    let mut commands = Vec::new();
    for line in reader.lines().map_while(Result::ok) {
        commands.push(line);
    }

    let mut index = 0;
    while index < commands.len() {
        parse_command_with_block(&commands, &mut index, &mut turtle);
    }
    File::create(image_path)?;
    let extension = image_path.extension().and_then(|s| s.to_str());
    match extension {
        Some("svg") => turtle
            .image
            .save_svg(image_path)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e)),
        Some("png") => turtle
            .image
            .save_png(image_path)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e)),
        _ => Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "File extension not supported",
        )),
    }
}

fn parse_command_with_block(commands: &[String], index: &mut usize, turtle: &mut Turtle) {
    let line = &commands[*index];
    if (line.trim().starts_with("IF") || line.trim().starts_with("WHILE")) && line.contains('[') {
        let mut block = line.clone();
        let mut bracket_count = 1;
        *index += 1; // Move past the IF line itself

        while *index < commands.len() && bracket_count > 0 {
            let current_line = &commands[*index].trim();

            if current_line.contains('[') {
                block += "!";
                block += current_line;
                bracket_count += current_line.matches('[').count();
            } else if current_line.contains(']') {
                block += current_line;
                block += "!";
                bracket_count -= current_line.matches(']').count();
            } else {
                block += current_line;
                //eprintln!("{}",current_line);
                if **current_line != *"" {
                    block += "\n";
                }
            }

            *index += 1;
        }

        // Now, `block` contains the entire IF block as a single string

        match parse_command(&block) {
            Ok(comm) => {
                turtle.execute_command(comm.clone()).unwrap();
                //eprintln!("{:?}",comm);
            }
            Err(e) => {
                eprintln!("{}", e);
                process::exit(1);
            }
        }
    } else {
        // Normal command or IF command without block (not expected in given format)

        match parse_command(line) {
            Ok(comm) => {
                //eprintln!("{:?}",comm);
                turtle.execute_command(comm).unwrap();
            }
            Err(e) => {
                eprintln!("{}", e);
                process::exit(1);
            }
        }
        *index += 1; // Move to the next command
    }
}
