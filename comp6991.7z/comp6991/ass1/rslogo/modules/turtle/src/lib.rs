
use std::result;
use command::Command;
use command::{Block as Block};
use command::Parameter as Parameter;
use std::io::{self};
use std::collections::HashMap;
use unsvg::Image;
use unsvg::get_end_coordinates;
use unsvg::COLORS;

use command::VARIABLES;

#[derive(Clone)]
pub struct Turtle {
    x: f32,
    y: f32,
    heading: f32,
    pen_down: bool,
    pen_color_num: f32,
    variables: HashMap<String, f32>,
    //procedures: HashMap<String, (Vec<String>, Block)>,
    pub image: Image,
}

impl Turtle {
    pub fn new(width:u32,height:u32) -> Self {
        Self {
            x: width as f32/2.0,
            y: height as f32/2.0,
            heading: 0.0,
            pen_down: false,
            pen_color_num: 7.0,
            variables: HashMap::new(),
            //procedures: HashMap::new(),
            image: Image::new(width, height),
            
        }
        
    }

    fn penup(&mut self) {
        self.pen_down = false;
    }

    fn pendown(&mut self) {
        self.pen_down = true;
    }

    fn forward(&mut self, distance: f32) {
    
        if self.pen_down {
            //eprintln!("{}",self.pen_color_num);
            let result = self.image.draw_simple_line(self.x,self.y,self.heading as i32,distance,COLORS[self.pen_color_num as usize]);
            match result {
                Ok((end_x,end_y)) => {
                    self.x = end_x;
                    self.y = end_y;
                },
                Err(_e) => {
                    // 处理错误
                }
            }
            
        }else{
            let result = get_end_coordinates(self.x,self.y,self.heading as i32,distance);
            self.x = result.0;
            self.y = result.1;
        }
        self.uptodate();
    }
    fn back(&mut self, distance: f32) {
        self.forward(-distance);
    }
    fn left(&mut self, distance: f32) {
        self.heading += 90.0;
        self.forward(-distance);
        self.heading -= 90.0;

    }
    fn right(&mut self, distance: f32) {
 
        self.heading -= 90.0;
        self.forward(-distance);
        self.heading += 90.0;
        
    }
    fn set_pen_color(&mut self, num: f32) {
        self.pen_color_num = num;
        self.uptodate();
    }
    fn turn(&mut self, degrees: f32) {
        self.heading += degrees;
        self.uptodate();
    }
    fn set_heading(&mut self, degrees: f32) {
        self.heading = degrees;
        self.uptodate();
    }
    fn set_x(&mut self, x: f32) {
        self.x = x;
        self.uptodate();
    }
    fn set_y(&mut self, y: f32) {
        self.y = y;
        self.uptodate();
    }
    fn make(&mut self, name: String, param: Parameter) -> Result<()> {
        //eprintln!("make{} {:?}",name,param);
        let value = match param {
            Parameter::F32(distance) => distance,
            Parameter::Variable(var_name) => {
                
                match var_name.as_str() {
                    "XCOR" => self.xcor(),
                    "YCOR" => self.ycor(),
                    "HEADING" => self.heading(),
                    "COLOR" => self.color(), 
                    "TRUE" => 999.99,
                    "FALSE" => 1000.00,
                    _ => {
                        //let param = var_name.trim_matches(':');
                        match self.variables.get_mut(&var_name) {
                            Some(var) => *var,
                            None => return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid query method")),
                                
                        }
                    },
                }
            },
        };
        
        self.variables.insert(name.clone(), value.clone());
        //eprintln!("{:?}",self.variables);
        {
            let mut variables = VARIABLES.lock().unwrap();
            variables.insert(name.clone(), value.clone());
        } 
        self.uptodate();
        Ok(())
    }
    fn uptodate(&mut self){

        let mut variables = VARIABLES.lock().unwrap();
        variables.insert("XCOR".to_string(), self.xcor());
        variables.insert("YCOR".to_string(), self.ycor());
        variables.insert("HEADING".to_string(), self.heading());
        variables.insert("COLOR".to_string(), self.color());
        variables.insert("TRUE".to_string(), 999.99);
        variables.insert("FALSE".to_string(), 1000.00);
    }
    fn addassign(&mut self, name: String, param: Parameter) -> Result<()> {
        
        let value = match param {
            Parameter::F32(distance) => distance,
            Parameter::Variable(var_name) => {
                
                match var_name.as_str() {
                    "XCOR" => self.xcor(),
                    "YCOR" => self.ycor(),
                    "HEADING" => self.heading(),
                    "COLOR" => self.color(), 
                    "TRUE" => 999.99,
                    "FALSE" => 1000.00,
                    _ => {
                        let head = "\"";
                        let var_name = var_name.trim_matches(':');
                        let var_name = head.to_owned()+var_name;
                        match self.variables.get_mut(&var_name) {
                            Some(var) => *var,
                            None => return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid query method")),
                                
                        }
                    }

                }
            },
        };
        
        //eprintln!("{:?}",self.variables);
        match self.variables.get_mut(&name) {
            Some(var) => {
                *var += value;
                //eprintln!("{} {}",name,var);
                let var = *var;
                self.variables.insert(name.clone(), var);
            },
            None => return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid query method")),
                
        }
        //eprintln!("addassign{} {:?} {:?}",name,value,self.variables);
        //eprintln!("{} {:?} {:?}",name,self.color(),self.variables.get_mut(&name));
        self.uptodate();
        Ok(())
    }
    fn xcor(&self) -> f32 {
        self.x
    }

    fn ycor(&self) -> f32 {
        self.y
    }

    fn heading(&self) -> f32 {
        self.heading
    }
    fn color(&self) -> f32 {
        self.pen_color_num
    }

    fn getvariable(&mut self, variablle: Parameter) -> f32{
        //eprintln!("{:?} {:?}",variablle,self.variables);
        match variablle {
            Parameter::F32(distance) => {
                return distance
            },
            Parameter::Variable(var_name) => {
                match var_name.as_str() {
                    "XCOR" => self.xcor(),
                    "YCOR" => self.ycor(),
                    "HEADING" => self.heading(),
                    "COLOR" => self.color(), 
                    "TRUE" => 999.99,
                    "FALSE" => 1000.00,
                    _ => {
                        let head = "\"";
                        let var_name = var_name.trim_matches(':');
                        let var_name = head.to_owned()+var_name;
                        match self.variables.get_mut(&var_name) {
                            Some(var) => {
                                return *var
                            },
                            None => return -1.003,
                                
                        }
                    },
                }

            },
        }
    }
    fn if_eq(&mut self, name1: Parameter, name2: Parameter, block: Block) -> Result<()> {

        let num1 = self.getvariable(name1.clone());
        let num2 = self.getvariable(name2.clone());
        //eprintln!("ifeq{:?} {:?}",name1,name2);
        //eprintln!("ifeq{:?} {:?}",num1,num2);
        //eprintln!("{:?}",self.variables);
        if num1 == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable1 does not exist"))
        }
        if num2 == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable2 does not exist"))
        }
        
        if num1 == num2 {
            //eprintln!("what?");
            let _ = self.execute_block(&block);

        }

        
        Ok(())
    }
    fn while_eq(&mut self, name1: Parameter, name2: Parameter, block: Block) ->Result<()> {
        let num1 = self.getvariable(name1.clone());
        let num2 = self.getvariable(name2.clone());
        //eprintln!("{:?} {:?}",name1,name2);
        //eprintln!("{:?} {:?}",num1,num2);
        if num1 == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable1 does not exist"))
        }
        if num2 == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable2 does not exist"))
        }


        if num1 == num2 {
            
            let _ = self.execute_block(&block);
            self.uptodate();
            let _ = self.while_eq(name1,name2,block);
            
        }
        
        Ok(())
    }



    fn execute(&mut self, param: Parameter, func: fn(&mut Self, f32)) -> Result<()> {
        
        let var = self.getvariable(param.clone());

        if var == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable does not exist"))
        }else{
            func(self, var);
            Ok(())
        }
    }
    fn execute1(&mut self, param: Parameter, func: fn(&mut Self, f32)) -> Result<()> {
        
        let var = self.getvariable(param.clone());
        //eprintln!("yesyesyes{:?} {:?}",var,param);
        if var == -1.003{
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Variable does not exist"))
        }else{
            func(self, var);
            Ok(())
        }
    }
    
    pub fn execute_command(&mut self, command: Command) -> Result<()>{
        
        match command {
            Command::PenUp => {
                self.penup();
                Ok(())
            },
            Command::PenDown =>{
                self.pendown();
                Ok(())
            },
            Command::Forward(param) => match self.execute(param, Self::forward){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::Back(param) => match self.execute(param, Self::back){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::Left(param) => match self.execute(param, Self::left){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::Right(param) => match self.execute(param, Self::right){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::SetPenColor(param) => match self.execute1(param, Self::set_pen_color){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::Turn(param) => match self.execute(param, Self::turn){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::SetHeading(param) => match self.execute(param, Self::set_heading){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::SetX(param) => match self.execute(param, Self::set_x){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::SetY(param) => self.execute(param, Self::set_y),
            Command::Make(name, value) => self.make(name, value),
            Command::AddAssign(name, value) => self.addassign(name, value),

            Command::IfEq(name1, name2, block) => match self.if_eq(name1, name2,block){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },
            Command::WhileEq(name1, name2, block) => match self.while_eq(name1, name2,block){
                Ok(_) => Ok(()),
                Err(e) => Err(e),
            },

            Command::NoOp => {
                Ok(())
            },
            Command::Block(_block) => {
                // TODO: 在这里添加处理Block的逻辑
                Ok(())
            },
        }
        
    }
    fn execute_block(&mut self, block: &Block) -> Result<()> {
        for command in &block.commands {
            self.execute_command(command.clone())?;
        }
        Ok(())
    }
    
}
type Result<T> = result::Result<T, io::Error>;
