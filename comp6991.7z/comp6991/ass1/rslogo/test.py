import os
import subprocess
import filecmp
import argparse

# 解析命令行参数
parser = argparse.ArgumentParser()
parser.add_argument("prefix", nargs='?', default='', help="Prefix of the test files to run")
args = parser.parse_args()

# 定义命令行参数
command1 = ["6991", "cargo", "run", "{filename}", "{outputpath}", "400", "400"]
command2 = ["6991", "rslogo", "{filename}", "{outputpath}", "400", "400"]

# 遍历logo_examples目录下的所有文件
for filename in sorted(os.listdir('logo_examples')):
    # 检查文件名是否以参数开头
    if not filename.startswith(args.prefix):
        continue

    # 构造完整的文件路径
    full_filename = os.path.join('logo_examples', filename)
    
    # 构造输出文件路径
    output1 = os.path.join("output", filename.split('.')[0] + '_cargo.svg')
    output2 = os.path.join("output", filename.split('.')[0] + '_rslogo.svg')
    
    # 运行命令
    
    # 运行命令
    error1 = None
    try:
        subprocess.check_output([arg.format(filename=full_filename, outputpath=output1) for arg in command1], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        error1 = e.output.decode()

    error2 = None
    try:
        subprocess.check_output([arg.format(filename=full_filename, outputpath=output2) for arg in command2], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        error2 = e.output.decode()
    
    # 检查两个命令是否都报错
    if error1 is not None and error2 is not None:
        print(f"{filename}: True")
    elif error1 is not None or error2 is not None:
        print(f"Error running command on {filename}")
        print(f"{filename}: False")
    # 比较两个输出文件是否相同
    elif filecmp.cmp(output1, output2, shallow=False):
        print(f"{filename}: True")
    else:
        print(f"{filename}: False")

