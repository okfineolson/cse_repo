use std::io;

fn main() {
    print!("What is your name? ");

    // Allocate memory for the name
    let mut name = String::new();
    io::stdin().read_line(&mut name).expect("Failed to read line");

    // Trim the newline character
    name = name.trim().to_string();

    // If the name is empty, print a message and exit
    if name.is_empty() {
        println!("No name entered :(, goodbye.");
        std::process::exit(1);
    } else {
        println!("Hello, {}, nice to meet you!", name);
    }
}
