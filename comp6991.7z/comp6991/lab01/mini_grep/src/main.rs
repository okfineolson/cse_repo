fn main() {
    let pattern_string = std::env::args()
        .nth(1)
        .expect("missing required command-line argument: <pattern>");

    let pattern = &pattern_string;

    // TODO: Replace the following with your code:
    loop {
        let mut input = String::new();
        std::io::stdin().read_line(&mut input).unwrap();

        input = input.trim().to_string();//delete \n 
        if input.contains(pattern) {
            println!("{}", input);
        } else if input.is_empty() {
            return;
        }
    }
}
