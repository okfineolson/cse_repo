use image::{ImageBuffer, Rgb};
use bmp::{Image, Pixel};

fn main() {
    // Create a new 200x200 image buffer
    let width = 200;
    let height = 200;
    let mut img = ImageBuffer::new(width, height);

    // Fill the image with a gradient pattern
    for y in 0..height {
        for x in 0..width {
            let r = (x as f32 / width as f32 * 255.0) as u8;
            let g = (y as f32 / height as f32 * 255.0) as u8;
            let b = 128; 
            img.put_pixel(x, y, Rgb([r, g, b]));
        }
    }


    let mut bmp_img = Image::new(width, height);
    for y in 0..height {
        for x in 0..width {
            let pixel = img.get_pixel(x, y);
            bmp_img.set_pixel(x as u32, y as u32, Pixel::new(pixel[0], pixel[1], pixel[2]));
        }
    }
    bmp_img.save("output").expect("Failed to save image");
}
