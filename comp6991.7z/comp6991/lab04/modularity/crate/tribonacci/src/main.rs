// tribonacci/src/main.rs


use tribonacci_lib::{compute_tribonacci};

mod utils;

fn main() {
    let shift_size = utils::first_argument();

    if let Err(e) = compute_tribonacci(shift_size) {
        println!("Error: {}", e.message())
    }
}
