const ENROLMENTS_PATH: &str = "enrolments.psv";


use std::collections::HashMap;
use std::fs::File;
use std::io::{self, BufRead};
use std::path::Path;

fn main() -> io::Result<()> {
    let path = Path::new(ENROLMENTS_PATH);
    let file = File::open(&path)?;
    let reader = io::BufReader::new(file);

    let mut students: HashMap<String, f64> = HashMap::new();
    let mut course_counts: HashMap<String, i32> = HashMap::new();

    for line in reader.lines() {
        let line = line?;
        let data: Vec<&str> = line.split('|').collect();

        let course_code = data[0].to_string();
        let zid = data[1].to_string();
        let wam: f64 = data[5].parse().unwrap();


        students.entry(zid).or_insert(wam);

        let count = course_counts.entry(course_code).or_insert(0);
        *count += 1;
    }

    let student_count = students.len();
    let avg_wam: f64 = students.values().sum::<f64>() / student_count as f64;


    let mut most_common = ("", 0);
    let mut least_common = ("", std::i32::MAX);

    for (course, count) in &course_counts {
        if *count > most_common.1 {
            most_common = (course, *count);
        }
        if *count < least_common.1 {
            least_common = (course, *count);
        }
    }

    println!("Number of students: {}", student_count);
    println!("Most common course: {} with {} students", most_common.0, most_common.1);
    println!("Least common course: {} with {} students", least_common.0, least_common.1);
    println!("Average WAM: {:.2}", avg_wam);

    Ok(())
}
