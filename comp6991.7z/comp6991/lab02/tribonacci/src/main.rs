use std::env;
use std::num::ParseIntError;

struct TribonacciError(String);

fn main() {
    let args: Vec<String> = env::args().collect();
    let error_message = String::from("Please enter a valid size");

    let size = match args.get(1) {
        Some(s) => s.parse::<usize>(),
        None => Ok(10),
    };

    if let Err(e) = compute_tribonacci(size, error_message) {
        println!("Error: {}", e.0)
    }
}

/// Computes the tribonacci sequence of a given size
/// Prints the sequence, and its sum
fn compute_tribonacci(
    size: Result<usize, ParseIntError>,

    // The error message your function should return
    // inside the `TribonacciError` struct
    error_msg: String,
) -> Result<(), TribonacciError> {
    let n = match size {
        Ok(s) if s >= 3 && s <= 145 => s,
        _ => return Err(TribonacciError(error_msg)),
    };
    let mut tribonacci:Vec<u128> = vec![1, 1, 1];
    for index in 3..n {
        let next = tribonacci[index - 1] + tribonacci[index - 2] + tribonacci[index - 3];
        tribonacci.push(next);
    }

    let sum: u128 = tribonacci.iter().map(|&x| x as u128).sum();

    println!("Values: {:?}\n",  tribonacci);
    println!("Sum: {}", sum);
    // TODO: complete this function!
    Ok(())
}
