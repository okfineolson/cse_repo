use std::collections::VecDeque;
use std::collections::LinkedList;
use std::collections::HashMap;
const MAX_ITER: i32 = 300000;

fn main() {
    // Vectors
    vec_operations();

    // VecDeque
    vec_deque_operations();

    // TODO: your code here, for linked list insertions
    linkedlist_operations();
    // TODO: your code here, for hashmap insertions
    hashmap_operations();
    // TODO: your text explanation to the questions in the spec
    /*
    ==== Vector ====
    insert: 4.038836ms
    remove: 3.887603419s
    ==== VecDeque ====
    insert: 5.064752ms
    remove: 4.384221ms
    ==== LinkedList ====
    insert: 30.066883ms
    remove: 11.975172ms
    ==== HashMap ====
    insert: 208.508096ms
    remove: 131.34756ms
    
    1,After print out all the time cost of four collection type, Vector operation
    was the fastest for adding and removing elements.

    2.VecDeque uses single, contiguous buffer but split it as two part, head and tail,  
    Adding to the start of the collection will add to the start of the head, 
    eating into the same space. 

    while vec uses only one buffer and Adding an item at the end is fast,
    but adding an item at the start requires copying all of the existing items to make space.

    Most operations on VecDeque are made more complicated by this layout and this will slightly reduce its performance. 
    Even retrieving its length is more complicated

    3.The whole point of VecDeque is to make certain operations faster, 
    namely pushing and popping the start of the collection. Vec is very slow at this, 
    especially if there are a lot of items, because it involves moving all of the other items to make space. 
    The structure of VecDeque makes these operations fast
    2 and 3 are both referenced at :https://www.deepl.com/translator#en/zh/%0A%0AMost%20operations%20on%20VecDeque%20are%20made%20more%20complicated%20by%20this%20layout%20and%20this%20will%20slightly%20reduce%20its%20performance.%20Even%20retrieving%20its%20length%20is%20more%20complicated%3A%0A%0Apub%20fn%20len(%26self)%20-%3E%20usize%20%7B%0A%20%20%20%20count(self.tail%2C%20self.head%2C%20self.cap())%0A%7D%0AThe%20whole%20point%20of%20VecDeque%20is%20to%20make%20certain%20operations%20faster%2C%20namely%20pushing%20and%20popping%20the%20start%20of%20the%20collection.%20Vec%20is%20very%20slow%20at%20this%2C%20especially%20if%20there%20are%20a%20lot%20of%20items%2C%20because%20it%20involves%20moving%20all%20of%20the%20other%20items%20to%20make%20space.%20The%20structure%20of%20VecDeque%20makes%20these%20operations%20fast%20but%20at%20the%20expense%20of%20performance%20of%20other%20operations%20in%20comparison%20to%20Vec.%0A%0AYour%20tests%20doesn't%20appear%20to%20take%20advantage%20of%20VecDeque's%20design%2C%20since%20they%20are%20dominated%20by%20calls%20to%20insert%2C%20which%20involves%20the%20expensive%20copying%20of%20many%20items%20in%20both%20cases.
    
    4.If there are many inserts at random positions, vec wouldn't be efficient, which linkedlist will be better.

    5.kind of, I imagin that HashMap will take longer but which is 40 times longger than vec in insert.
    */
    
}

/// measure the insertion and removal
/// operations of a vector
fn vec_operations() {
    let mut vec = Vec::new();

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        vec.push(i);
    }
    let time_end = std::time::Instant::now();

    println!("==== Vector ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        vec.remove(0);
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}
fn linkedlist_operations(){
    let mut vec = LinkedList::new();
    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER{
        vec.push_back(i)
    }
    let time_end = std::time::Instant::now();
    println!("==== LinkedList ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        vec.pop_front();
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}
fn hashmap_operations(){
    let mut vec = HashMap::new();
    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER{
        vec.insert(i, i);
    }
    let time_end = std::time::Instant::now();
    println!("==== HashMap ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        vec.remove(&i);
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}
/// measure the insertion and removal
/// operations of a VecDeque
fn vec_deque_operations() {
    let mut vec_deque = VecDeque::new();

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        vec_deque.push_back(i);
    }
    let time_end = std::time::Instant::now();

    println!("==== VecDeque ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        vec_deque.pop_front();
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}
