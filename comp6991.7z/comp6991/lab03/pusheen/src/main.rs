fn main() {
    let mut vec = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    {//this code is invalid because we cannot borrow s as mutable more than once at a time. 
    //The first mutable borrow is in a and must last until it’s used in push
        let a = &mut vec;
        a.push(11);
    }//we can use curly brackets to create a new scope, allowing for multiple mutable references, just not simultaneous ones:
    let b = &mut vec;
    b.push(12);
}
