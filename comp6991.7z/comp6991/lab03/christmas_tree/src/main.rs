use serde::Deserialize;
use std::collections::VecDeque;
use std::io;

#[derive(Debug, Deserialize)]
enum Instruction {
    Set(i32),
    Left,
    Right,
    Reset,
}


#[derive(Debug)]
struct Light {
    left: Option<Box<Light>>,
    right: Option<Box<Light>>,
    brightness: i32,
}

fn get_instructions_from_stdin() -> VecDeque<Instruction> {
    let mut instructions = String::new();
    io::stdin().read_line(&mut instructions).unwrap();
    ron::from_str(&instructions).unwrap()
}

fn main() {
    let instructions = get_instructions_from_stdin();
    let mut root_light = Light { left: None, right: None, brightness: 0};
    
    let mut current_light = &mut root_light;


    for i in instructions{
        match i {
            Instruction::Set(brightness) => {
                current_light.brightness = brightness;
            },
            Instruction::Left => {
                if current_light.left.is_none() {
                    current_light.left = Some(Box::new(Light { left: None, right: None, brightness: 0 }));
                }
                current_light = current_light.left.as_mut().unwrap();
            },
            Instruction::Right => {
                if current_light.right.is_none() {
                    current_light.right = Some(Box::new(Light { left: None, right: None, brightness: 0 }));
                }
                current_light = current_light.right.as_mut().unwrap();
            },
            Instruction::Reset => {
                current_light = &mut root_light;
            },
        }
    }
    
    let average_brightness = calculate_average_brightness(&root_light);
    println!("{:?}", average_brightness);

    // TODO: your implementation here
}
fn calculate_average_brightness(root: &Light) -> i32 {
    let mut sum = root.brightness ;
    let mut count = 1;
    let mut queue: VecDeque<&Light> = VecDeque::new();
    queue.push_back(root);

    while let Some(node) = queue.pop_front() {
        if let Some(left) = &node.left {
            sum += left.brightness ;
            count += 1;
            queue.push_back(left);
        }
        if let Some(right) = &node.right {
            sum += right.brightness;
            count += 1;
            queue.push_back(right);
        }
    }

    sum / count as i32
}