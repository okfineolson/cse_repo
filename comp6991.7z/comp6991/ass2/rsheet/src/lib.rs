mod spreadsheet;

use rsheet_lib::connect::{ConnectionError, Manager, Reader, Writer};
use rsheet_lib::replies::Reply;
use spreadsheet::Spreadsheet;
use std::error::Error;

use std::sync::{Arc, Mutex};
use std::thread;

pub fn start_server<M>(mut manager: M) -> Result<(), Box<dyn Error>>
where
    M: Manager,
{
    let spreadsheet = Arc::new(Mutex::new(Spreadsheet::new()));
    let mut threads = vec![];
    while let Ok((mut recv, mut send)) = manager.accept_new_connection() {
        let spreadsheet = Arc::clone(&spreadsheet);
        let thread = thread::spawn(move || loop {
            match recv.read_message() {
                Ok(msg) => {
                    let parts: Vec<&str> = msg.split_whitespace().collect();
                    let mut spreadsheet = spreadsheet.lock().unwrap();

                    match parts[0] {
                        "get" => {
                            let reply = spreadsheet.get(parts[1]);
                            send.write_message(reply).unwrap();
                        }
                        "set" => {
                            let expression = parts[2..].join(" ");
                            let reply = spreadsheet.set(parts[1], &expression);
                            match reply {
                                Ok(_) => {}
                                Err(e) => send.write_message(e).unwrap(),
                            }
                        }
                        _ => send
                            .write_message(Reply::Error("Invalid command".to_string()))
                            .unwrap(),
                    }
                }
                Err(ConnectionError::ConnectionClosed) => break,
                Err(_e) => break,
            }
        });
        threads.push(thread);
    }
    for thrad in threads {
        thrad.join().unwrap();
    }
    Ok(())
}
