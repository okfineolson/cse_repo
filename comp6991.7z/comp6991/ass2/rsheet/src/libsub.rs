
use rsheet_lib::replies::Reply;
use rsheet_lib::command_runner::CommandRunner;
use std::collections::{HashMap,HashSet};
use rsheet_lib::command_runner::CellArgument;
use rsheet_lib::cell_value::CellValue;

pub struct Spreadsheet {
    cells: HashMap<String, CellValue>,
    dependencies: HashMap<String, HashSet<String>>,
    errorcheckdependent: HashMap<String, HashSet<String>>,
    expressions: HashMap<String, String>,
}

impl Spreadsheet {
    pub fn new() -> Self {
        Self {
            cells: HashMap::new(),
            dependencies: HashMap::new(),
            expressions: HashMap::new(),
            errorcheckdependent: HashMap::new(),
            
        }
    }

    pub fn get(&self, cell: &str) -> Reply {
        if self.has_circular_dependency(cell) {
            return Reply::Error(format!("Cell {} is self-referential", cell));
        }
        if self.has_error_dependency(cell) {
            
            return Reply::Error(format!("Cell {} depends on a cell with an error", cell));
        }
        
        match self.cells.get(cell) {
            Some(value) => Reply::Value(cell.to_string(), value.clone()),
            None => Reply::Value(cell.to_string(), CellValue::None),
        }
    }

    pub fn set(&mut self, cell: &str, expression: &str) -> Result<(), Reply> {
        let runner = CommandRunner::new(expression);

        // check does the expression be empty
        if expression.is_empty() {
            return Err(Reply::Error(format!("No value provided for cell {}", cell)));
        }
        
        let variables = runner.find_variables()
            .into_iter()
            .filter_map(|var| {
                if var.contains('_') {
                    // Handle vector and matrix variables

                    let sum = self.sum(&var,cell);
                    Some((var, sum))
                } else {
                    // Handle scalar variables
                    //eprintln!("{:?},{:?}",cell,var);
                    match self.cells.get(&var) {
                        Some(val) => {
                            if let CellValue::Error(e) = val {
                                
                                return Some((var, CellArgument::Value(CellValue::Error(e.to_string())))); 
                            }
                            
                            self.dependencies.entry(var.to_string()).or_default().insert(cell.to_string());
                            self.errorcheckdependent.entry(cell.to_string()).or_default().insert(var.to_string());
                            
                            Some((var, CellArgument::Value(val.clone())))
                        },
                        None =>{
                            
                            //self.dependencies.entry(var.to_string()).or_insert_with(HashSet::new).insert(cell.to_string());
                            Some((var, CellArgument::Value(CellValue::None)))
                        },  // if expression variable not exist,set cell to None
                    }
                }
            })
            .collect::<HashMap<_, _>>();
        //eprintln!("{:?},{:?}",cell,self.dependencies);

        for var in variables.keys() {
            self.dependencies.entry(var.to_string()).or_default.insert(cell.to_string());
            self.errorcheckdependent.entry(cell.to_string()).or_default().insert(var.to_string());
        
        }
        
        let result = runner.run(&variables);

       
        if self.has_circular_dependency(cell) {
            return Ok(());
        }

        self.cells.insert(cell.to_string(), result.clone());
        self.expressions.insert(cell.to_string(), expression.to_string());

        let dependents = self.dependencies.get(cell).cloned().unwrap_or_default();
        //eprintln!("{:?},{:?}",cell,dependents);
        // Now, update dependents
        for dependent in dependents {
            if let Some(expression) = self.expressions.get(&dependent) {
                let str_exp = expression.to_string();
                //eprintln!("{:?},{:?}",dependent,str_exp);
                self.set(&dependent, &str_exp)?;
            }
        }

        Ok(())
    }
    pub fn sum(&mut self, range: &str, current_cell: &str) -> CellArgument {
        let cells: Vec<&str> = range.split('_').collect();
        let start = cells[0];
        let end = cells[1];
    
        let start_letter = start.chars().next().unwrap();
        let end_letter = end.chars().next().unwrap();
    
        let start_number: i32 = start[1..].parse().unwrap();
        let end_number: i32 = end[1..].parse().unwrap();
    
        let mut values = Vec::new();
    
        for letter in start_letter..=end_letter {
            for number in start_number..=end_number {
                let cell = format!("{}{}", letter, number);
                self.dependencies.entry(cell.clone()).or_default().insert(current_cell.to_string());
                if let Some(value) = self.cells.get(&cell) {
                    values.push(value.clone());
                }
            }
        }
    
        CellArgument::Vector(values)
    }
    fn has_circular_dependency(&self, cell: &str) -> bool {
        let mut visited = HashSet::new();
        let mut stack = HashSet::new();
        self.dfs(cell, &mut visited, &mut stack)
    }
    fn has_error_dependency(&self, cell: &str) -> bool {
        //eprintln!("{:?},{:?}",cell,self.errorcheckdependent);
        if let Some(dependents) = self.errorcheckdependent.get(cell) {
            for dependent in dependents {
                //eprintln!("{:?}",dependent);
                if let Some(value) = self.cells.get(dependent) {
                    if matches!(value, CellValue::Error(_)) {
                        return true;
                    }
                }
            }
        }
        false
    }
    
 
    
    fn dfs(&self, cell: &str, visited: &mut HashSet<String>, stack: &mut HashSet<String>) -> bool {
        visited.insert(cell.to_string());
        stack.insert(cell.to_string());

        if let Some(cells) = self.dependencies.get(cell) {
            for next_cell in cells {
                if (!visited.contains(next_cell) && self.dfs(next_cell, visited, stack)) || stack.contains(next_cell) {
                    return true;
                }
                
            }
        }

        stack.remove(cell);
        false
    }
}