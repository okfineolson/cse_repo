1) I saw someone's code fail to compile because they 
were trying to send non-thread-safe data across threads. 
How does the Rust language allow for static (i.e. at compile time)
guarantees that specific data can be sent/shared acrosss threads?

Rust provides static guarantees that specific data can be sent/shared across threads through the Send and Sync traits:

The Send trait indicates that ownership of the type implementing this trait can be transferred safely between threads. 
The Sync trait indicates that it is safe to share a type implementing this trait between threads.

When try to send or share data across threads, the Rust compiler checks whether these types implement the Send or Sync traits. If they don’t, the compiler will throw an error, preventing data races and other concurrency issues.


2) Do you have to then implement the Send and Sync traits for 
every piece of data (i.e. a struct) you want to share and send across threads?

No,you don't.In Rust, many types are Send and Sync by default.

However, if you create a struct that contains a type that is not Send or Sync , then that struct will also not be Send or Sync. In such cases, you would need to use a thread-safe variant or wrap it in a type that provides thread safety .

3) What types in the course have I seen that aren't Send? Give one example, 
and explain why that type isn't Send 
Rc<T>,Rc<T> is not Send is because it is not safe to share across threads. Rc<T> uses non-atomic operations for incrementing and decrementing the reference count. This means that if Rc<T> were shared across threads, and two threads simultaneously called clone or dropped a clone of the Rc<T>

4) What is the relationship between Send and Sync? Does this relate
to Rust's Ownership system somehow?
The Send trait is used to ensure that a type can be safely moved from one thread to another. This is directly related to Rust’s ownership system, as moving a value typically involves transferring ownership from one part of the program to another. If a type implements Send, it means that the ownership of values of that type can be transferred across threads.
The Sync trait is used to ensure that a type can be safely shared between threads by providing a reference to the value (&T). This is also related to Rust’s ownership system, as sharing a value typically involves borrowing a reference to the value. If a type implements Sync, it means that references to a value of that type can be safely shared across threads.
5) Are there any types that could be Send but NOT Sync? Is that even possible?
yes, it is possible for a type to be Send but not Sync.

A type is Send if it is safe to transfer it to another thread. However, being Sync means it is safe to share references to a value across threads.

For example, consider Cell<T> from the Rust standard library. Cell<T> allows for interior mutability, meaning you can change the value it contains even when Cell<T> is immutable. However, Cell<T> is not thread-safe because it uses non-atomic operations. Therefore, Cell<T> is Send (assuming T is Send), but it is not Sync.

This means you can pass a Cell<T> from one thread to another, but you cannot share a Cell<T> between threads by reference.
6) Could we implement Send ourselves using safe rust? why/why not?
