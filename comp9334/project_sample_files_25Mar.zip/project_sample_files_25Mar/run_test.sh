python3 main.py $1
